package uern.oop.escola;

public class Disciplina
{

	public String nome;

	public Disciplina(String nome)
	{

		this.nome = nome;

	}

}
