package uern.oop.velha;

public class Placar{

	public Integer player1;
	public Integer player2;

	public Placar(){
		
		player1 = 0;
		player2 = 0;
	}

}
